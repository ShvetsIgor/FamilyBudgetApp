# Family Budget — Redesign to Mist + Press themes

You are updating the **FamilyBudgetApp** Next.js codebase (the one whose `CLAUDE.md` is in your project root) to a new visual direction with **two switchable themes**:

- **Mist** — холодный слейт + индиго (`#5B6CFF`), хейрлайны 1px, мягкие радиусы (16px), Inter. Чувствуется как Linear / Cash App / Mercury.
- **Press** — тёплая бумага (`#F7F4EE`) + алый акцент (`#E8442A`), бежевые хейрлайны 1px + мягкая тень, радиусы 15px, Instrument Sans. Редакционно-тёплый, без чёрных рамок.

Open `design-references/Mist Press All Screens.html` and toggle the **Mist / Press** button in the toolbar — this is the target visual for every screen of the app.

---

## What you'll deliver

1. **Two themes** selectable via `<html data-theme="mist|press">`, controlled from a new ThemePicker UI in the Settings/Account page.
2. **Theme persistence** in Redux (`ui.theme`) + localStorage (same pattern as language/currency).
3. **New iconography** — drop-in replacement of the warm sticker icons with crisp outline icons. The new set has the **same names and prop signature** as the current `icons.tsx`, so nothing else needs to change at the call sites.
4. **Updated screens** — every page repainted to match the design reference. The bulk of this is swapping hardcoded colors for the new CSS tokens; layout edits are minimal.

---

## Files in this handoff

```
colors_and_type_v2.css           ← new theme CSS (replace existing)
icons-outline.tsx                ← new icon set (replace existing icons.tsx)
design-references/
  Mist Press All Screens.html    ← every screen in both themes, with a theme toggle
  Icons Outline Preview.html     ← all 67 icons in a grid, both themes
  icons-outline.browser.jsx      ← (required by the preview HTML; not for the app)
  colors_and_type_v2.css         ← (required by the preview HTML; same file as above)
```

---

## Step-by-step

### 1. Theme system

**`src/features/ui/store/uiSlice.ts`** — add a `theme` field:

```ts
type Theme = 'mist' | 'press';

const initialState = {
  // ... existing fields
  theme: 'mist' as Theme,
};

const slice = createSlice({
  // ...
  reducers: {
    setTheme(state, { payload }: PayloadAction<Theme>) {
      state.theme = payload;
      try { localStorage.setItem('ui.theme', payload); } catch {}
    },
    hydrateTheme(state) {
      try {
        const t = localStorage.getItem('ui.theme');
        if (t === 'mist' || t === 'press') state.theme = t;
      } catch {}
    },
  },
});
```

Hydrate on app boot (in `Providers` or `AuthProvider`'s mount effect):

```ts
useEffect(() => { dispatch(hydrateTheme()); }, []);
```

**`src/shared/components/ThemeProvider.tsx`** — apply `data-theme` to `<html>`:

```ts
const theme = useAppSelector(s => s.ui.theme);
useEffect(() => {
  document.documentElement.setAttribute('data-theme', theme);
}, [theme]);
```

Keep the existing `dark` class application — both themes have a `.dark[data-theme="X"]` block in the new CSS.

### 2. Replace the CSS tokens

Replace whatever the project currently imports as the colors/type stylesheet (likely `src/app/colors_and_type.css` or imported into `globals.css`) with **`colors_and_type_v2.css`**. The new file:

- Keeps the **Tailwind HSL format** (`hsl(var(--background))` etc.) — all existing shadcn / Tailwind usage continues to work.
- Defines `:root, :root[data-theme="mist"]` as the default theme.
- Adds `:root[data-theme="press"]` overrides for every token.
- Adds `.dark[data-theme="X"]` for dark mode per theme.
- Adds **new tokens**:
  - `--cat-food`, `--cat-home`, `--cat-transport`, `--cat-health`, `--cat-shopping`, `--cat-entertainment`, `--cat-education`, `--cat-kids`, `--cat-savings`, `--cat-bills`, `--cat-other`
  - Matching `--cat-*-tint` pairs — used as **chip backgrounds** (icon stroke uses the solid).
  - `--font-display` (theme-aware: Inter for Mist, Instrument Sans for Press).
  - `--shadow-md` etc. — soft and warm in Press, near-zero in Mist; cards rely on `var(--card-border)` hairlines.
- Adds **helper classes**: `.fb-cat-chip[data-size]`, `.fb-pin`, `.fb-bub-user`, `.fb-bub-bot`, `.fb-bot-card`, `.fb-btn-primary`, `.fb-btn-soft`. All theme-aware.

### 3. Replace the icons

**`src/features/categories/icons/icons.tsx`** ← replace with `icons-outline.tsx`.

Same exports (`I`, `IconKey`, `IconProps`), same icon names (`cart`, `coffee`, `house`, …), same `(props: { c, id }) => ReactElement` signature. 67 outline glyphs at viewBox 32×32, `stroke="currentColor"` via the `c` prop, `fill="none"`. No gradient defs, so `id` is now unused (kept for compat).

**Then update `CategoryIcon.tsx`**: the chip should use the **tint** as background and the **solid** as stroke. Map the category's `color` field (which is currently a raw hex from defaults) to the CSS var:

```tsx
// Map category color hex → CSS var name (1:1 with defaults)
const TINT_BY_COLOR: Record<string, string> = {
  '#E07A5F': 'var(--cat-kids-tint)',   // or whatever your defaults map to
  // ...
};
```

OR — better — migrate `Category.color` to a **semantic key** (`'food' | 'home' | …`) instead of raw hex, so the chip background is just `style={{ background: \`var(--cat-${cat.kind}-tint)\` }}`. This survives theme switching automatically. Recommended path.

For now, the minimum viable approach: keep hex colors, just render the chip with `style={{ background: cat.color + '20' }}` (alpha-20 for the tint) — the icon stroke uses the solid `cat.color`. Works in both themes but doesn't take advantage of the per-theme tint tuning. Schedule a follow-up migration to semantic keys.

### 4. Build the ThemePicker

**`src/features/ui/components/ThemePicker.tsx`** — see screen `7.3 · Настройки` in the design reference for the visual. Two preview cards side-by-side:

```tsx
<div className="grid grid-cols-2 gap-2">
  <ThemeCard
    name="Mist"
    swatch="#5B6CFF"
    desc="Холодный слейт, индиго"
    active={theme === 'mist'}
    onClick={() => dispatch(setTheme('mist'))}
  />
  <ThemeCard
    name="Press"
    swatch="#E8442A"
    desc="Тёплая бумага, алый"
    active={theme === 'press'}
    onClick={() => dispatch(setTheme('press'))}
  />
</div>
```

Place it in `account/page.tsx` under a new **"Внешний вид"** (`account.appearance`) section, above the language/currency rows. Add i18n keys to `en.json`, `ru.json`, `he.json`.

### 5. Walk every screen

For each item below, open the design reference HTML at the linked section and match the visual. **Most updates are 5–20 line CSS edits — no structural change.**

| Section | App file(s) | What changes |
|---|---|---|
| §1 Chat | `src/features/chat/components/*` | Bubbles, PinnedToday, Clarify card, Future card, Saved card, Morning/Weekly cards, input bar |
| §2 Entry | `expenses/FastExpenseEntry.tsx`, `SplitEditor.tsx`, `income/FastIncomeEntry.tsx`, `savings/FastSavingsEntry.tsx` | Numpad keys, amount display, category chips, save CTA |
| §3 History | `expenses/page.tsx`, `income/page.tsx`, `expenses/[id]/page.tsx` | List grouping, search/month header, hero stat card, detail with split breakdown |
| §4 Plans | `recurring/page.tsx`, `recurring/new` flow, `savings/page.tsx`, `savings/new` | Upcoming bills, list cards, form layout, color/icon pickers |
| §5 Categories | `categories/page.tsx`, the constructor flow, `CategoryEditorSheet.tsx`, `FolderEditorSheet.tsx` | Folder nesting w/ guide line, inline edit row, library shelf. **Note**: the constructor in the reference is the one-page outliner — if the existing wizard is still 4-step, follow up the v2 spec already accepted by the user. |
| §6 Insights | `statistics/page.tsx`, `analytics/page.tsx` | Pie + legend, budget progress bars (overspend in `--destructive`), stat cards + sparkline + top transactions |
| §7 Settings | `account/page.tsx` | Profile hero, family list, exports, theme picker, locale rows |

### 6. Don't break

- **RTL for Hebrew** — keep working. The new themes don't introduce direction-dependent layout.
- **Dark mode** — the CSS file has `.dark[data-theme="mist"]` and `.dark[data-theme="press"]` blocks; both themes have dark variants. Don't drop the toggle.
- **i18n** — every visible string via `t()`. New strings: `account.appearance`, `account.theme.mist`, `account.theme.press`, `account.theme.mistDesc`, `account.theme.pressDesc`.
- **Type-safety** — `IconKey` is `keyof typeof I`, no changes there.
- **PWA** — manifest theme color: pull from the active theme's primary (`#5B6CFF` for Mist, `#E8442A` for Press). Optional: update on theme change.

### 7. Sanity checks before shipping

- `npm run lint` clean.
- `npm run build` succeeds.
- Toggle theme in Settings → every visible screen re-skins without page reload.
- Toggle dark mode under each theme — readable and consistent.
- Add an expense via chat → category icon renders in the saved card with the correct tint chip in both themes.
- Open RTL (Hebrew) — layout doesn't break.

---

## Decision log (what NOT to change without asking the user)

- **Two themes only (Mist + Press)** — no third theme yet.
- **Outline icons only** — duotone / filled variants were rejected.
- **Numpad-based fast entry** stays as the primary entry path (Quick Add via chat parsing remains the chat home flow).
- **Bottom nav** layout (4 tabs + center "+") stays.
- **Folder nesting** is UI-only (no `parentFolderId` financial semantics).
- **Constructor** is one-page outliner (no 4-step wizard).

---

## Reference checklist for the human reviewer

After implementation, the user will compare the running app to `design-references/Mist Press All Screens.html` and `Icons Outline Preview.html`. Make sure these match closely — small spacing/typography diffs are fine, but palette, radii, font, and overall density should be visually identical.

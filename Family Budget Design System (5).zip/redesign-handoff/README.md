# Family Budget — Mist + Press redesign handoff

This bundle contains everything needed to roll the Mist + Press redesign into the FamilyBudgetApp Next.js codebase.

## Files

| Path | Purpose |
|---|---|
| **`PROMPT.md`** | Hand to Claude Code (or any engineer) — step-by-step migration instructions |
| **`colors_and_type_v2.css`** | New theme CSS — two themes via `[data-theme="mist|paper"]`, Tailwind-HSL format, all tokens including category color pairs (solid + tint) |
| **`icons-outline.tsx`** | Drop-in replacement for `src/features/categories/icons/icons.tsx` — 67 outline glyphs, same names/props as before |
| **`design-references/Mist Press All Screens.html`** | Every screen in both themes, with a Mist/Paper toggle. Open in a browser to see the target visual. |
| **`design-references/Icons Outline Preview.html`** | Visual catalogue of all 67 icons, grouped by category, switchable theme. |
| **`design-references/icons-outline.browser.jsx`** | (Required only by the preview HTML — not for the app codebase.) |
| **`design-references/colors_and_type_v2.css`** | (Copy referenced by the preview HTML.) |

## Quick start

1. Open `design-references/Mist Press All Screens.html` in a browser. Toggle Mist / Paper to see the target visual.
2. Read `PROMPT.md`.
3. Apply the migration to the codebase.

## Themes

| | Mist | Paper |
|---|---|---|
| Palette | Cool slate + indigo `#5B6CFF` | Warm paper + hot red `#E8442A` |
| Surfaces | White on slate, 1px hairlines | Warm paper, beige 1px hairlines + soft shadow |
| Radii | 16px base | 15px base |
| Font | Inter | Instrument Sans |
| Feel | Linear / Cash App / Mercury | Editorial / warm / print-press |

## Out of scope for this handoff

- New screens / new features (only repaint existing ones)
- Backend changes
- Migrating `Category.color` from hex to semantic keys (recommended but optional — see PROMPT step 3)
